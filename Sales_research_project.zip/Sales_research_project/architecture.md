# Architecture — AI Lead Generation & Research Agent

## 1. System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        FastAPI (port 8000)                  │
│  POST /research  GET /lead/{id}  POST /rank  POST /outreach │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│              LangGraph StateGraph (linear pipeline)         │
│                                                             │
│  ┌───────────────┐  ┌──────────────────┐  ┌─────────────┐  │
│  │ ResearchAgent │→ │QualificationAgent│→ │  SalesAgent │  │
│  └───────────────┘  └──────────────────┘  └─────────────┘  │
└─────────────────────────────────────────────────────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
  DuckDuckGo +          FAISS Index +         Ollama LLM
  BeautifulSoup         SentenceTransformers  (llama3.2:3b)
                                                   │
                                                   ▼
                                         data/leads/{id}.json
```

All three agents read from and write to a single **GraphState** TypedDict.
No agent calls another directly — LangGraph manages the execution order.

---

## 2. Agent Flow

### GraphState (shared)
```python
class GraphState(TypedDict):
    keyword: str
    max_results: int
    location_filter: Optional[str]
    raw_leads: List[RawLead]           # written by ResearchAgent
    qualified_leads: List[QualifiedLead]  # written by QualificationAgent
    final_leads: List[FinalLead]       # written by SalesAgent
    errors: List[str]
    start_time: float
```

### ResearchAgent
1. Call `DuckDuckGo.text(keyword)` — two complementary queries
2. For each result URL: `requests.get()` + `BeautifulSoup` scrape
3. Extract: company name, website, location, description, decision-maker hints
4. Produce `List[RawLead]` → write to `state["raw_leads"]`

### QualificationAgent
1. Read `state["raw_leads"]`
2. Chunk each lead's evidence text (fixed-window, 512 chars, 50 overlap)
3. Embed chunks with `all-MiniLM-L6-v2` → add to in-memory FAISS index
4. Retrieve top-5 chunks per lead (by cosine similarity to keyword)
5. Score each lead using the deterministic rubric → `LeadScore`
6. Sort by score descending → write `List[QualifiedLead]` to state

### SalesAgent
1. Read `state["qualified_leads"]`
2. Rebuild FAISS index from evidence (needed for retrieval in this node)
3. Retrieve top-5 evidence chunks per lead
4. Build grounded prompt (RETRIEVED FACTS block + company + keyword)
5. Call Ollama `/api/generate` → outreach email
6. Run hallucination guard: sentence-level cosine similarity vs. chunks
7. Build factual summary (no LLM)
8. Save `FinalLead` to `data/leads/{id}.json`

---

## 3. RAG Pipeline

```
Evidence text (snippets + scraped page)
           │
           ▼
    [chunking.py]  chunk_text(size=512, overlap=50)
           │  List[str]
           ▼
  [embeddings.py]  SentenceTransformer.encode(normalize=True)
           │  np.ndarray float32
           ▼
 [vectorstore.py]  FAISS.IndexFlatIP.add()  ← inner product = cosine for normalized vectors
           │
           ▼  query time
  [retrieval.py]   embed(query) → FAISS.search(k=5) → List[str]
           │
           ▼
  [grounding.py]   check_grounding(generated, chunks, threshold=0.30)
                   → flag sentences with no matching chunk
```

**Why FAISS IndexFlatIP?**
- L2-normalised vectors from SentenceTransformer make inner product identical to cosine similarity
- Exact search (no approximation) — perfectly accurate for the dataset sizes in this project
- No server process required; runs in-process

**Hallucination prevention:**
- The prompt strictly says "ONLY use the RETRIEVED FACTS below"
- After generation, each sentence is embedded and checked against all retrieved chunks
- Sentences with max cosine similarity < 0.30 are flagged and logged
- The `OutreachDraft.flagged_sentences` field records every flagged sentence for transparency

---

## 4. Scoring Rubric

| Factor | Max pts | Logic |
|---|---|---|
| Website present | 20 | URL field non-empty |
| Description depth | 25 | `min(25, word_count / 200 * 25)` |
| Keyword relevance | 25 | `cosine_sim(description, keyword) * 25` |
| Location present | 10 | Location field non-empty |
| Decision-maker hint | 20 | Job-title regex hits × 5, capped at 20 |
| **Total** | **100** | |

The rubric is 100% deterministic. No LLM is used for scoring, making it reproducible and auditable.

---

## 5. Model Choice

**`llama3.2:3b`** (Meta, via Ollama)

| Property | Value |
|---|---|
| Parameters | 3 billion |
| Download size | ~2.0 GB |
| RAM required | ~4 GB (CPU-only) |
| Instruction following | Strong for < 500-token prompts |
| Generation speed (CPU) | ~5–15 tokens/s |

**Why this model?**
- Smallest Meta model with good instruction-following for structured output
- Runs on a laptop with 8 GB RAM without a GPU
- One-command setup: `ollama pull llama3.2:3b`
- Temperature set to 0.3 for consistent, focused output

**Embedding model:** `sentence-transformers/all-MiniLM-L6-v2`
- 384-dimensional dense vectors
- ~90 MB download
- Fast CPU inference (~500 sentences/second)
- Strong semantic similarity quality for English text

---

## 6. Quantization Strategy

Ollama handles quantization automatically. The default `llama3.2:3b` uses **Q4_K_M** quantization (4-bit, K-means, medium quality):

| Quantization | Size | Quality loss | Use case |
|---|---|---|---|
| `fp16` (no quant) | ~6 GB | none | GPU with VRAM |
| `Q8_0` | ~3.2 GB | minimal | High-RAM CPU |
| `Q4_K_M` ✅ default | ~2.0 GB | small | Standard laptop |
| `Q2_K` | ~1.1 GB | noticeable | Very low RAM |

To use a specific quantization:
```bash
ollama pull llama3.2:3b:q8_0   # higher quality, more RAM
```

---

## 7. GPU Requirements

This project is designed to run **without a GPU**:

| Hardware | Performance |
|---|---|
| CPU only, 8 GB RAM | Functional, ~15–60s per request |
| CPU only, 16 GB RAM | Comfortable, ~10–30s per request |
| NVIDIA GPU (4 GB VRAM) | Fast, ~3–8s per request |
| NVIDIA GPU (8+ GB VRAM) | Very fast, < 3s per request |

Ollama detects and uses the GPU automatically if available (CUDA/ROCm).
No code changes needed — switching from CPU to GPU is transparent.

---

## 8. Fine-Tuning Strategy (QLoRA / Unsloth)

### When fine-tuning beats prompting
Fine-tuning is better than prompting when:
- You have 500+ labeled examples of ideal outreach emails
- The base model consistently ignores prompt constraints (e.g., writes too long)
- You need consistent output format (JSON, specific subject line structure)
- Latency is critical and you want to remove the long system prompt

### QLoRA approach
```
Base model: llama3.2:3b (or mistral:7b for higher quality)
Framework:  Unsloth (4–5× faster than standard PEFT)
Adapter:    LoRA  rank=16, alpha=32, target=q_proj,v_proj
Precision:  4-bit NF4 quantization during training
Dataset:    {company_name, evidence_chunks} → {subject, body} pairs
Epochs:     3–5
Batch size: 4 (gradient accumulation × 4 = effective 16)
Hardware:   1× NVIDIA RTX 3090 (24 GB) or Google Colab A100
```

```python
# Minimal Unsloth training sketch
from unsloth import FastLanguageModel
model, tokenizer = FastLanguageModel.from_pretrained("unsloth/llama-3.2-3b-instruct-bnb-4bit")
model = FastLanguageModel.get_peft_model(model, r=16, lora_alpha=32)
# ... SFTTrainer with your outreach dataset
trainer.train()
model.save_pretrained("./fine_tuned_outreach_model")
```

### When to prefer prompting (current approach)
- Fewer than 200 labeled examples
- Budget constraints (no GPU for training)
- Assignment/prototype context — prompting is faster to iterate

---

## 9. Scaling Approach

| Concern | Current (assignment) | Production |
|---|---|---|
| LLM | Ollama (single process) | vLLM / TGI with load balancer |
| Search | DuckDuckGo (rate-limited) | Paid API (Brave, SerpAPI) + caching |
| Vector store | In-memory FAISS per request | Persistent Qdrant / Weaviate cluster |
| Storage | JSON files | PostgreSQL + pgvector |
| Concurrency | Single worker | Multiple uvicorn workers + task queue (Celery/Redis) |
| Pipeline | Synchronous | Async with background jobs + SSE streaming |
| Embedding | Single process | Dedicated embedding service (TEI) |

Horizontal scaling path:
```
Load Balancer
    │
    ├── API Worker 1  (FastAPI)
    ├── API Worker 2  (FastAPI)
    └── API Worker N  (FastAPI)
              │
              ├── Embedding Service  (all-MiniLM via TEI)
              ├── LLM Service        (vLLM: llama3.2)
              ├── Vector DB          (Qdrant cluster)
              └── Task Queue         (Redis + Celery)
```

---

## 10. Monitoring Strategy

### Logged events (structured JSON, via `app/core/logging.py`)

| Event type | Fields logged |
|---|---|
| `latency` | operation name, elapsed_s |
| `agent` | agent name, action (start/complete), data dict |
| `api_failure` | endpoint, error string |
| `lead_quality` | lead_id, score, hallucination_flags count, flagged sentences |

### Key metrics to watch

| Metric | Threshold | Action |
|---|---|---|
| Request latency | > 120s | LLM unavailable — check Ollama |
| Lead score avg | < 30/100 | Search quality poor — tune queries |
| Hallucination flag rate | > 20% sentences | Lower model temperature or raise threshold |
| DuckDuckGo failures | > 3 per hour | Rate-limited — add delay or use paid API |
| `ollama_connected: false` | any | Ollama not running — alert |

### Production additions (out of scope for assignment)
- **Prometheus metrics** via `prometheus-fastapi-instrumentator`
- **Grafana dashboard** for per-endpoint P50/P95/P99 latency
- **Sentry** for exception tracking
- **Alert rules** on hallucination rate and avg lead score degradation
