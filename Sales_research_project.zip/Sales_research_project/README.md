# AI Lead Generation & Research Agent

A production-style multi-agent system for automated B2B lead research, qualification, and personalized outreach generation.

**Stack**: Python · FastAPI · LangGraph · SentenceTransformers · FAISS · Ollama · DuckDuckGo Search · Pydantic v2

---

## Architecture Overview

```
POST /research
      │
      ▼
 [ResearchAgent]          DuckDuckGo search + BeautifulSoup scraping
      │  raw_leads[]
      ▼
 [QualificationAgent]     Chunk → Embed → FAISS → Retrieve → Score
      │  qualified_leads[]
      ▼
 [SalesAgent]             Retrieve → Grounded Ollama prompt → Outreach draft
      │  final_leads[]
      ▼
 data/leads/{id}.json     JSON persistence
```

---

## Quick Start

### 1. Clone and install

```bash
cd Sales_research_project
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Set up environment

```bash
cp .env.example .env
# Edit .env if you want to change OLLAMA_MODEL or DATA_DIR
```

### 3. Start Ollama and pull the model

```bash
# Install Ollama: https://ollama.com/download
ollama serve &
ollama pull llama3.2:3b
```

### 4. Run the API server

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000/docs** for the interactive Swagger UI.

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama server URL |
| `OLLAMA_MODEL` | `llama3.2:3b` | Model to use for generation |
| `DATA_DIR` | `./data` | Root directory for JSON storage |
| `LOG_LEVEL` | `INFO` | Logging verbosity |
| `TOP_K_CHUNKS` | `5` | Number of RAG chunks retrieved per query |
| `CHUNK_SIZE` | `512` | Characters per chunk |
| `CHUNK_OVERLAP` | `50` | Overlap between consecutive chunks |
| `MAX_SEARCH_RESULTS` | `10` | Max DuckDuckGo results per request |
| `GROUNDING_THRESHOLD` | `0.30` | Min cosine sim for a sentence to be grounded |

---

## API Endpoints

### `GET /health`
Check that the server is running and Ollama is reachable.

```bash
curl http://localhost:8000/health
```

```json
{
  "status": "ok",
  "ollama_connected": true,
  "ollama_model": "llama3.2:3b",
  "version": "1.0.0"
}
```

---

### `POST /research`
Run the full pipeline: search → qualify → generate outreach.

```bash
curl -X POST http://localhost:8000/research \
  -H "Content-Type: application/json" \
  -d '{
    "keyword": "fintech startups India",
    "max_results": 5
  }'
```

**Response** (`200 OK`):
```json
{
  "job_id": "uuid",
  "status": "completed",
  "keyword": "fintech startups India",
  "leads_found": 4,
  "leads": [ { "company_name": "...", "score": {...}, "outreach": {...} } ],
  "processing_time_seconds": 38.1,
  "errors": []
}
```

---

### `GET /lead/{lead_id}`
Retrieve a stored lead by its UUID.

```bash
curl http://localhost:8000/lead/a1b2c3d4-e5f6-7890-abcd-ef1234567890
```

---

### `POST /rank`
Load a set of leads and return them sorted.

```bash
curl -X POST http://localhost:8000/rank \
  -H "Content-Type: application/json" \
  -d '{
    "lead_ids": ["id1", "id2", "id3"],
    "sort_by": "score"
  }'
```

`sort_by` options: `score` (default) · `company_name` · `location`

---

### `POST /outreach`
Regenerate outreach for an existing lead (change tone or retry after failure).

```bash
curl -X POST http://localhost:8000/outreach \
  -H "Content-Type: application/json" \
  -d '{
    "lead_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "tone": "friendly"
  }'
```

`tone` options: `professional` (default) · `friendly` · `formal`

---

## Running Tests

```bash
# Fast tests only (schemas, scoring, chunking — no model loading)
pytest tests/ -m "not slow" -v

# All tests including grounding (loads embedding model, ~30s first run)
pytest tests/ -v
```

---

## Project Structure

```
app/
  main.py                  FastAPI application + lifecycle hooks
  core/
    config.py              Pydantic Settings (all env vars)
    logging.py             Structured JSON logging helpers
  api/
    routes.py              5 API endpoints
  agents/
    graph.py               LangGraph StateGraph + GraphState TypedDict
    research_agent.py      Web search + scraping node
    qualification_agent.py Embedding + FAISS + scoring node
    sales_agent.py         Retrieval + grounded outreach node
  rag/
    chunking.py            Fixed-window text chunking
    embeddings.py          SentenceTransformer singleton wrapper
    vectorstore.py         FAISS index (IndexFlatIP) + metadata dict
    retrieval.py           Top-k semantic search helpers
    grounding.py           Per-sentence hallucination guard
  services/
    web_search.py          DuckDuckGo DDGS wrapper
    scraper.py             BeautifulSoup page scraper
    scoring.py             Deterministic 100-pt scoring rubric
    outreach.py            Ollama HTTP client + grounded prompt builder
    lead_store.py          JSON save/load/list
  schemas/
    lead.py                RawLead → QualifiedLead → FinalLead
    requests.py            API request bodies
    responses.py           API response bodies
  utils/
    text_cleaning.py       HTML strip, name/location extraction
    validators.py          URL + keyword validation, sanitization
data/
  leads/                   One JSON file per final lead
  indexes/                 Optional FAISS index saves
tests/
  conftest.py
  test_schemas.py
  test_scoring.py
  test_chunking.py
  test_grounding.py
  fixtures/
    sample_lead.json
    sample_search_results.json
```

---

## Model Alternatives

If `llama3.2:3b` is too slow on your machine, try:

| Model | Size | RAM | Command |
|---|---|---|---|
| `llama3.2:3b` ✅ default | 2.0 GB | ~4 GB | `ollama pull llama3.2:3b` |
| `phi3:mini` | 2.3 GB | ~4 GB | `ollama pull phi3:mini` |
| `gemma2:2b` | 1.6 GB | ~3 GB | `ollama pull gemma2:2b` |
| `qwen2.5:0.5b` | 0.4 GB | ~2 GB | `ollama pull qwen2.5:0.5b` |

Change the model without touching code:
```bash
OLLAMA_MODEL=gemma2:2b uvicorn app.main:app --reload
```
