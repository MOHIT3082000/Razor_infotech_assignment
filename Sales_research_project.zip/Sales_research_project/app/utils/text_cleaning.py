"""
Text cleaning and field extraction utilities.
These are heuristic helpers — no LLM involved.
"""
from __future__ import annotations

import re
from typing import List


def clean_text(text: str) -> str:
    """Strip HTML artifacts, collapse whitespace, remove non-printable characters."""
    if not text:
        return ""
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)
    # Remove non-printable / control characters except newlines
    text = re.sub(r"[^\x20-\x7E\n]", " ", text)
    # Collapse whitespace
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_emails(text: str) -> List[str]:
    """Return all email addresses found in text."""
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    return list(set(re.findall(pattern, text)))


def extract_phones(text: str) -> List[str]:
    """Return all phone numbers found in text (basic pattern)."""
    pattern = r"(?:\+?\d{1,3}[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}"
    return list(set(re.findall(pattern, text)))


def extract_names(text: str) -> List[str]:
    """
    Extract potential person names that appear near job titles.
    Uses two patterns:
    - Title before name: "CEO John Smith"
    - Name before title: "John Smith, CEO"
    """
    title_before = re.compile(
        r"\b(?:CEO|CTO|CFO|COO|Director|Manager|Founder|Co-Founder|President|VP|Head)\b"
        r"[,\s]+([A-Z][a-z]+(?:\s[A-Z][a-z]+)+)",
        re.IGNORECASE,
    )
    name_before = re.compile(
        r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)+)"
        r"\s*,\s*(?:CEO|CTO|CFO|COO|Director|Manager|Founder|Co-Founder|President|VP|Head)",
        re.IGNORECASE,
    )
    names: List[str] = []
    for pattern in (title_before, name_before):
        names.extend(pattern.findall(text))
    return list({n.strip() for n in names if n.strip()})


def extract_locations(text: str) -> List[str]:
    """Extract location mentions using common phrasing patterns."""
    patterns = [
        re.compile(
            r"(?:located|headquartered|based)\s+in\s+([A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)",
            re.IGNORECASE,
        ),
        re.compile(
            r"offices?\s+in\s+([A-Z][a-z]+(?:[,\s]+[A-Z][a-z]+)*)",
            re.IGNORECASE,
        ),
    ]
    locations: List[str] = []
    for pattern in patterns:
        locations.extend(pattern.findall(text))
    return list({loc.strip() for loc in locations if loc.strip()})
