"""
Input validation and sanitization helpers.
Used at API boundary and before processing user-supplied strings.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse


def validate_url(url: str) -> bool:
    """Return True only if url has http/https scheme and a netloc."""
    if not url or not isinstance(url, str):
        return False
    try:
        parsed = urlparse(url.strip())
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


def validate_keyword(keyword: str) -> bool:
    """
    Keyword must be 2–200 characters.
    Blocks obvious injection sequences: <, >, {, }, \\, |, backtick.
    """
    if not keyword or not isinstance(keyword, str):
        return False
    keyword = keyword.strip()
    if len(keyword) < 2 or len(keyword) > 200:
        return False
    if re.search(r"[<>{}\\\|`]", keyword):
        return False
    return True


def sanitize_company_name(name: str) -> str:
    """
    Remove dangerous characters from a company name.
    Returns 'Unknown Company' for empty/None input.
    """
    if not name or not isinstance(name, str):
        return "Unknown Company"
    # Strip known injection / template characters
    name = re.sub(r"[<>{}\\\|`]", "", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:200] if name else "Unknown Company"
