from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class ResearchRequest(BaseModel):
    """Request body for POST /research."""

    keyword: str = Field(
        ...,
        min_length=2,
        max_length=200,
        description="Business keyword or category to research (e.g. 'fintech startups India')",
    )
    max_results: int = Field(default=10, ge=1, le=50, description="Max search results to process")
    location_filter: Optional[str] = Field(
        default=None,
        max_length=100,
        description="Optional location hint to bias results (e.g. 'India')",
    )


class RankRequest(BaseModel):
    """Request body for POST /rank."""

    lead_ids: List[str] = Field(..., min_length=1, description="List of lead IDs to rank")
    sort_by: str = Field(
        default="score",
        pattern="^(score|company_name|location)$",
        description="Sort field: score | company_name | location",
    )


class OutreachRequest(BaseModel):
    """Request body for POST /outreach."""

    lead_id: str = Field(..., description="ID of the stored lead to generate outreach for")
    tone: str = Field(
        default="professional",
        pattern="^(professional|friendly|formal)$",
        description="Email tone: professional | friendly | formal",
    )
