from __future__ import annotations

from typing import List

from pydantic import BaseModel

from app.schemas.lead import FinalLead, OutreachDraft


class ResearchResponse(BaseModel):
    """Response for POST /research — full pipeline result."""

    job_id: str
    status: str
    keyword: str
    leads_found: int
    leads: List[FinalLead]
    processing_time_seconds: float
    errors: List[str] = []


class LeadResponse(BaseModel):
    """Response for GET /lead/{lead_id}."""

    lead: FinalLead


class RankResponse(BaseModel):
    """Response for POST /rank — sorted lead list."""

    keyword: str = ""
    total: int
    ranked_leads: List[FinalLead]


class OutreachResponse(BaseModel):
    """Response for POST /outreach — regenerated outreach draft."""

    lead_id: str
    company_name: str
    outreach: OutreachDraft


class HealthResponse(BaseModel):
    """Response for GET /health."""

    status: str
    ollama_connected: bool
    ollama_model: str
    version: str = "1.0.0"
