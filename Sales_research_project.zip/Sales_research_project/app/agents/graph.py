"""
LangGraph state machine definition.

GraphState is the single shared object passed between all three agents.
Each node returns a dict with the keys it wants to update; LangGraph
merges that dict into the running state.

Node order:  research → qualify → sales → END
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph

from app.core.logging import get_logger
from app.schemas.lead import FinalLead, QualifiedLead, RawLead

logger = get_logger(__name__)


# ── Shared pipeline state ──────────────────────────────────────────────────────

class GraphState(TypedDict):
    keyword: str
    max_results: int
    location_filter: Optional[str]

    # Agent outputs (each agent writes its own layer)
    raw_leads: List[RawLead]
    qualified_leads: List[QualifiedLead]
    final_leads: List[FinalLead]

    # Diagnostics
    errors: List[str]
    start_time: float


# ── Graph factory ──────────────────────────────────────────────────────────────

def _build_graph():
    # Import here to break circular-import at module level
    from app.agents.research_agent import research_node
    from app.agents.qualification_agent import qualify_node
    from app.agents.sales_agent import sales_node

    builder = StateGraph(GraphState)

    builder.add_node("research", research_node)
    builder.add_node("qualify", qualify_node)
    builder.add_node("sales", sales_node)

    builder.add_edge(START, "research")
    builder.add_edge("research", "qualify")
    builder.add_edge("qualify", "sales")
    builder.add_edge("sales", END)

    return builder.compile()


# Lazy singleton — compiled once on first use
_graph: Any = None


def get_graph():
    """Return the compiled LangGraph pipeline (singleton)."""
    global _graph
    if _graph is None:
        logger.info("Compiling LangGraph pipeline …")
        _graph = _build_graph()
        logger.info("LangGraph pipeline ready.")
    return _graph


# ── State initialiser ──────────────────────────────────────────────────────────

def create_initial_state(
    keyword: str,
    max_results: int = 10,
    location_filter: Optional[str] = None,
) -> GraphState:
    return GraphState(
        keyword=keyword,
        max_results=max_results,
        location_filter=location_filter,
        raw_leads=[],
        qualified_leads=[],
        final_leads=[],
        errors=[],
        start_time=time.time(),
    )
