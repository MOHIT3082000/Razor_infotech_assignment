"""
Sales Agent — LangGraph node.

Responsibilities:
  1. Rebuild a FAISS index from qualified lead evidence.
  2. Retrieve top-k grounding chunks per lead.
  3. Generate a personalized outreach email via Ollama (grounded prompt).
  4. Run the hallucination guard on the generated text.
  5. Build a factual summary (no LLM).
  6. Persist each FinalLead to disk.
  7. Write final_leads + errors back to GraphState.
"""
from __future__ import annotations

import time
from typing import Dict, List

from app.agents.graph import GraphState
from app.core.config import settings
from app.core.logging import get_logger, log_agent_event, log_latency, log_lead_quality
from app.rag.chunking import chunk_lead_evidence
from app.rag.embeddings import get_embedding_model
from app.rag.grounding import check_grounding
from app.rag.retrieval import retrieve_for_lead
from app.rag.vectorstore import FAISSStore
from app.schemas.lead import FinalLead
from app.services.lead_store import save_lead
from app.services.outreach import generate_outreach

logger = get_logger(__name__)


# ── node ───────────────────────────────────────────────────────────────────────

def sales_node(state: GraphState) -> Dict:
    """
    Sales Agent node.

    Reads:  state["qualified_leads"], state["keyword"], state["start_time"]
    Writes: state["final_leads"], state["errors"]
    """
    qualified_leads = state.get("qualified_leads", [])
    keyword: str = state["keyword"]
    pipeline_start: float = state.get("start_time", time.time())
    errors: List[str] = list(state.get("errors", []))

    log_agent_event(logger, "SalesAgent", "start", {"leads": len(qualified_leads)})

    if not qualified_leads:
        logger.warning("SalesAgent: no qualified leads received.")
        return {"final_leads": [], "errors": errors}

    embedder = get_embedding_model()

    # ── Rebuild FAISS index from qualified lead evidence ───────────────────────
    store = FAISSStore(dim=embedder.dim)
    for lead in qualified_leads:
        chunks = chunk_lead_evidence(
            lead.evidence_snippets,
            chunk_size=settings.chunk_size,
            overlap=settings.chunk_overlap,
        )
        if not chunks:
            chunks = [lead.description or lead.company_name or keyword]
        embeddings = embedder.embed(chunks)
        urls = (lead.source_urls or [""])[:1] * len(chunks)
        store.add_chunks(chunks, embeddings, lead_id=lead.id, source_urls=urls)

    # ── Process each lead ──────────────────────────────────────────────────────
    final_leads: List[FinalLead] = []

    for lead in qualified_leads:
        try:
            with log_latency(logger, f"SalesAgent.outreach:{lead.id[:8]}"):
                # 1. Retrieve grounding evidence
                retrieved_chunks = retrieve_for_lead(
                    lead.id, keyword, store, embedder, k=settings.top_k_chunks
                )

                # 2. Generate outreach (LLM call, grounded prompt)
                outreach_draft = generate_outreach(lead, retrieved_chunks, tone="professional")

                # 3. Hallucination guard on the generated body
                all_evidence = list(dict.fromkeys(retrieved_chunks + lead.evidence_snippets))
                grounding_result = check_grounding(
                    outreach_draft.body, all_evidence, embedder
                )
                outreach_draft.grounded = grounding_result.is_grounded
                outreach_draft.flagged_sentences = grounding_result.flagged_sentences

                # 4. Factual summary (no LLM)
                summary = _build_summary(lead, retrieved_chunks)

                processing_time = round(time.time() - pipeline_start, 2)

                final_lead = FinalLead(
                    **lead.model_dump(),
                    summary=summary,
                    outreach=outreach_draft,
                    processing_time_seconds=processing_time,
                )

            # 5. Persist to disk
            save_lead(final_lead)
            final_leads.append(final_lead)

            log_lead_quality(
                logger,
                lead.id,
                lead.score.total,
                grounding_result.flagged_sentences,
            )

        except Exception as exc:
            msg = f"SalesAgent failed for '{lead.company_name}': {exc}"
            logger.error(msg)
            errors.append(msg)

    log_agent_event(
        logger,
        "SalesAgent",
        "complete",
        {"final_leads": len(final_leads), "errors": len(errors)},
    )

    return {"final_leads": final_leads, "errors": errors}


# ── helpers ────────────────────────────────────────────────────────────────────

def _build_summary(lead, chunks: List[str]) -> str:
    """
    Build a concise factual summary from retrieved evidence — no LLM.
    Joins key metadata fields with the most relevant retrieved chunk.
    """
    parts: List[str] = [f"Company: {lead.company_name}"]
    if lead.location:
        parts.append(f"Location: {lead.location}")
    if lead.website:
        parts.append(f"Website: {lead.website}")
    if chunks:
        parts.append(f"Evidence: {chunks[0][:300]}")
    parts.append(f"Score: {lead.score.total}/100")
    parts.append(lead.score.reasoning)
    return " | ".join(parts)
