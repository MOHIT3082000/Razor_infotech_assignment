"""
Qualification Agent — LangGraph node.

Responsibilities:
  1. Chunk all raw lead evidence.
  2. Embed chunks and add them to a shared FAISS index.
  3. Retrieve top-k evidence chunks per lead.
  4. Score every lead using the deterministic rubric.
  5. Sort qualified leads by score (descending).
  6. Write qualified_leads + errors back to GraphState.
"""
from __future__ import annotations

from typing import Dict, List

from app.agents.graph import GraphState
from app.core.config import settings
from app.core.logging import get_logger, log_agent_event, log_latency
from app.rag.chunking import chunk_lead_evidence
from app.rag.embeddings import get_embedding_model
from app.rag.retrieval import retrieve_for_lead
from app.rag.vectorstore import FAISSStore
from app.schemas.lead import QualifiedLead
from app.services.scoring import score_lead

logger = get_logger(__name__)


def qualify_node(state: GraphState) -> Dict:
    """
    Qualification Agent node.

    Reads:  state["raw_leads"], state["keyword"]
    Writes: state["qualified_leads"], state["errors"]
    """
    raw_leads = state.get("raw_leads", [])
    keyword: str = state["keyword"]
    errors: List[str] = list(state.get("errors", []))

    log_agent_event(logger, "QualificationAgent", "start", {"leads": len(raw_leads)})

    if not raw_leads:
        logger.warning("QualificationAgent: no raw leads received.")
        return {"qualified_leads": [], "errors": errors}

    embedder = get_embedding_model()
    store = FAISSStore(dim=embedder.dim)

    # ── Phase 1: chunk + embed all leads into one FAISS index ─────────────────
    with log_latency(logger, "QualificationAgent.indexing"):
        for lead in raw_leads:
            chunks = chunk_lead_evidence(
                lead.evidence_snippets,
                chunk_size=settings.chunk_size,
                overlap=settings.chunk_overlap,
            )
            # Guarantee at least one chunk so the lead is searchable
            if not chunks:
                fallback = lead.description or lead.company_name or keyword
                chunks = [fallback]

            embeddings = embedder.embed(chunks)
            urls = (lead.source_urls or [""])[:1] * len(chunks)
            store.add_chunks(chunks, embeddings, lead_id=lead.id, source_urls=urls)

    # ── Phase 2: retrieve evidence + score ────────────────────────────────────
    qualified_leads: List[QualifiedLead] = []

    with log_latency(logger, "QualificationAgent.scoring"):
        for lead in raw_leads:
            try:
                retrieved = retrieve_for_lead(
                    lead.id, keyword, store, embedder, k=settings.top_k_chunks
                )
                score = score_lead(lead, keyword, embedder)

                ql = QualifiedLead(
                    **lead.model_dump(),
                    score=score,
                    retrieved_chunks=retrieved,
                    chunk_sources=lead.source_urls[: len(retrieved)],
                )
                qualified_leads.append(ql)

            except Exception as exc:
                msg = f"Scoring failed for '{lead.company_name}': {exc}"
                logger.error(msg)
                errors.append(msg)

    # Sort best leads first
    qualified_leads.sort(key=lambda l: l.score.total, reverse=True)

    top_score = qualified_leads[0].score.total if qualified_leads else 0.0
    log_agent_event(
        logger,
        "QualificationAgent",
        "complete",
        {"qualified": len(qualified_leads), "top_score": top_score},
    )

    return {"qualified_leads": qualified_leads, "errors": errors}
