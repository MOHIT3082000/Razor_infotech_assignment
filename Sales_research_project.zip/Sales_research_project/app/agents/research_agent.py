"""
Research Agent — LangGraph node.

Responsibilities:
  1. Call DuckDuckGo for the keyword.
  2. Scrape each result URL.
  3. Normalise the raw data into RawLead objects.
  4. Write raw_leads + errors back to GraphState.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Dict, List

from app.agents.graph import GraphState
from app.core.logging import get_logger, log_agent_event, log_latency
from app.schemas.lead import RawLead
from app.services.scraper import extract_lead_fields, scrape_page
from app.services.web_search import search_leads
from app.utils.validators import sanitize_company_name, validate_url

logger = get_logger(__name__)


def research_node(state: GraphState) -> Dict:
    """
    Research Agent node.

    Reads:  state["keyword"], state["max_results"]
    Writes: state["raw_leads"], state["errors"]
    """
    keyword: str = state["keyword"]
    max_results: int = state.get("max_results", 10)
    errors: List[str] = list(state.get("errors", []))

    log_agent_event(logger, "ResearchAgent", "start", {"keyword": keyword, "max_results": max_results})

    raw_leads: List[RawLead] = []

    # ── 1. Web search ──────────────────────────────────────────────────────────
    with log_latency(logger, "ResearchAgent.search"):
        search_results = search_leads(keyword, max_results=max_results)

    log_agent_event(logger, "ResearchAgent", "search_done", {"hits": len(search_results)})

    # ── 2. Scrape + normalise ──────────────────────────────────────────────────
    for result in search_results:
        url: str = result.get("url", "")
        title: str = result.get("title", "")
        snippet: str = result.get("snippet", "")

        if not validate_url(url):
            logger.debug(f"Skipping invalid URL: {url!r}")
            continue

        with log_latency(logger, f"ResearchAgent.scrape:{url[:40]}"):
            page_text = scrape_page(url)

        fields = extract_lead_fields(page_text, url, title, snippet)
        company_name = sanitize_company_name(fields.get("company_name", "Unknown"))

        lead = RawLead(
            id=str(uuid.uuid4()),
            company_name=company_name,
            website=fields.get("website"),
            industry=None,
            location=fields.get("location"),
            description=fields.get("description", ""),
            decision_maker_hints=fields.get("decision_maker_hints", []),
            source_urls=fields.get("source_urls", [url]),
            evidence_snippets=fields.get("evidence_snippets", []),
            keyword=keyword,
            created_at=datetime.utcnow(),
        )

        # Append raw page text as additional evidence (truncated to keep memory sane)
        raw_text: str = fields.get("raw_text", "")
        if raw_text and raw_text not in lead.evidence_snippets:
            lead.evidence_snippets.append(raw_text[:1500])

        raw_leads.append(lead)

    log_agent_event(
        logger,
        "ResearchAgent",
        "complete",
        {"leads_collected": len(raw_leads), "errors": len(errors)},
    )

    return {"raw_leads": raw_leads, "errors": errors}
