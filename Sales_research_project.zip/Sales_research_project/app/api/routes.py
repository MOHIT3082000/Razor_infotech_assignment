"""
FastAPI route definitions.

Endpoints:
  POST /research          — run the full 3-agent pipeline
  GET  /lead/{lead_id}    — retrieve a stored lead by ID
  POST /rank              — load and sort a set of leads
  POST /outreach          — regenerate outreach for an existing lead
  GET  /health            — system health + Ollama connectivity check
"""
from __future__ import annotations

import asyncio
import time
import uuid

import httpx
from fastapi import APIRouter, HTTPException, status

from app.agents.graph import create_initial_state, get_graph
from app.core.config import settings
from app.core.logging import get_logger, log_api_failure, log_latency
from app.rag.chunking import chunk_lead_evidence
from app.rag.embeddings import get_embedding_model
from app.rag.vectorstore import FAISSStore
from app.schemas.requests import OutreachRequest, RankRequest, ResearchRequest
from app.schemas.responses import (
    HealthResponse,
    LeadResponse,
    OutreachResponse,
    RankResponse,
    ResearchResponse,
)
from app.services.lead_store import load_lead
from app.services.outreach import generate_outreach

router = APIRouter()
logger = get_logger(__name__)


# ── GET /health ────────────────────────────────────────────────────────────────

@router.get("/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    """Check that the API is running and test Ollama connectivity."""
    ollama_ok = False
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{settings.ollama_base_url}/api/tags")
            ollama_ok = resp.status_code == 200
    except Exception:
        pass

    return HealthResponse(
        status="ok",
        ollama_connected=ollama_ok,
        ollama_model=settings.ollama_model,
    )


# ── POST /research ─────────────────────────────────────────────────────────────

@router.post("/research", response_model=ResearchResponse, tags=["Leads"])
async def research_leads(request: ResearchRequest):
    """
    Run the full lead generation pipeline:
      Research Agent → Qualification Agent → Sales Agent

    Returns all final leads with scores, summaries, and outreach drafts.
    """
    job_id = str(uuid.uuid4())
    start = time.time()

    logger.info(
        f"[{job_id}] POST /research — keyword='{request.keyword}' max={request.max_results}"
    )

    try:
        initial_state = create_initial_state(
            keyword=request.keyword,
            max_results=request.max_results,
            location_filter=request.location_filter,
        )

        # Run the blocking LangGraph pipeline in a thread to keep the event loop free
        graph = get_graph()
        result = await asyncio.to_thread(graph.invoke, initial_state)

        final_leads = result.get("final_leads", [])
        errors = result.get("errors", [])
        elapsed = round(time.time() - start, 2)

        return ResearchResponse(
            job_id=job_id,
            status="completed",
            keyword=request.keyword,
            leads_found=len(final_leads),
            leads=final_leads,
            processing_time_seconds=elapsed,
            errors=errors,
        )

    except Exception as exc:
        log_api_failure(logger, "/research", str(exc))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        )


# ── GET /lead/{lead_id} ────────────────────────────────────────────────────────

@router.get("/lead/{lead_id}", response_model=LeadResponse, tags=["Leads"])
async def get_lead(lead_id: str):
    """Retrieve a previously stored lead by its UUID."""
    lead = load_lead(lead_id)
    if lead is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Lead '{lead_id}' not found.",
        )
    return LeadResponse(lead=lead)


# ── POST /rank ─────────────────────────────────────────────────────────────────

@router.post("/rank", response_model=RankResponse, tags=["Leads"])
async def rank_leads(request: RankRequest):
    """
    Load a set of leads by ID and return them sorted.
    sort_by: score (default) | company_name | location
    """
    leads = []
    for lid in request.lead_ids:
        lead = load_lead(lid)
        if lead:
            leads.append(lead)

    if not leads:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="None of the provided lead IDs were found.",
        )

    if request.sort_by == "score":
        leads.sort(key=lambda l: l.score.total, reverse=True)
    elif request.sort_by == "company_name":
        leads.sort(key=lambda l: l.company_name.lower())
    elif request.sort_by == "location":
        leads.sort(key=lambda l: (l.location or "").lower())

    keyword = leads[0].keyword if leads else ""
    return RankResponse(keyword=keyword, total=len(leads), ranked_leads=leads)


# ── POST /outreach ─────────────────────────────────────────────────────────────

@router.post("/outreach", response_model=OutreachResponse, tags=["Leads"])
async def generate_lead_outreach(request: OutreachRequest):
    """
    Regenerate a grounded outreach email for an existing stored lead.
    Useful for changing tone or retrying after an LLM failure.
    """
    lead = load_lead(request.lead_id)
    if lead is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Lead '{request.lead_id}' not found.",
        )

    try:
        embedder = get_embedding_model()
        store = FAISSStore(dim=embedder.dim)

        chunks = chunk_lead_evidence(
            lead.evidence_snippets,
            chunk_size=settings.chunk_size,
            overlap=settings.chunk_overlap,
        )
        if not chunks:
            chunks = [lead.description or lead.company_name]

        embeddings = embedder.embed(chunks)
        urls = (lead.source_urls or [""])[:1] * len(chunks)
        store.add_chunks(chunks, embeddings, lead_id=lead.id, source_urls=urls)

        q_vec = embedder.embed_one(lead.keyword)
        results = store.search_for_lead(q_vec, lead.id, k=settings.top_k_chunks)
        retrieved = [r.text for r in results if r.text.strip()]

        outreach = await asyncio.to_thread(generate_outreach, lead, retrieved, request.tone)

        return OutreachResponse(
            lead_id=lead.id,
            company_name=lead.company_name,
            outreach=outreach,
        )

    except Exception as exc:
        log_api_failure(logger, "/outreach", str(exc))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        )
