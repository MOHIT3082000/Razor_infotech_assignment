"""
Hallucination guard for the RAG pipeline.

Every sentence in the generated text is compared against the retrieved
chunks via cosine similarity.  Sentences with a max similarity below
*threshold* are flagged as potentially ungrounded and logged.

The filter_ungrounded() helper returns only the sentences that pass.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, List, Optional

import numpy as np

from app.core.config import settings
from app.core.logging import get_logger

if TYPE_CHECKING:
    from app.rag.embeddings import EmbeddingModel

logger = get_logger(__name__)


@dataclass
class GroundingResult:
    is_grounded: bool
    flagged_sentences: List[str] = field(default_factory=list)
    grounded_sentences: List[str] = field(default_factory=list)
    grounding_score: float = 0.0   # fraction of sentences that passed


# ── helpers ────────────────────────────────────────────────────────────────────

def _split_sentences(text: str) -> List[str]:
    """Split text into individual sentences (min 10 chars)."""
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p.strip() for p in parts if len(p.strip()) >= 10]


def _max_cosine(sent_vec: np.ndarray, chunk_vecs: np.ndarray) -> float:
    """Return the highest cosine similarity between sent_vec and any chunk vector."""
    if chunk_vecs.shape[0] == 0:
        return 0.0
    # Vectors are already L2-normalised → dot product == cosine similarity
    sims = chunk_vecs @ sent_vec
    return float(np.max(sims))


# ── public API ─────────────────────────────────────────────────────────────────

def check_grounding(
    generated_text: str,
    chunks: List[str],
    embedder: EmbeddingModel,
    threshold: Optional[float] = None,
) -> GroundingResult:
    """
    Check every sentence in *generated_text* against *chunks*.

    A sentence is considered grounded if its cosine similarity to at
    least one chunk exceeds *threshold*.

    Returns a GroundingResult with per-sentence verdicts.
    """
    threshold = threshold if threshold is not None else settings.grounding_threshold

    if not generated_text.strip():
        return GroundingResult(is_grounded=True, grounding_score=1.0)

    sentences = _split_sentences(generated_text)
    if not sentences:
        return GroundingResult(is_grounded=True, grounding_score=1.0)

    if not chunks:
        # Nothing to ground against — flag everything
        logger.warning("Grounding check called with empty chunk list; flagging all sentences.")
        return GroundingResult(
            is_grounded=False,
            flagged_sentences=sentences,
            grounded_sentences=[],
            grounding_score=0.0,
        )

    try:
        all_texts = sentences + chunks
        all_vecs = embedder.embed(all_texts)
        sent_vecs = all_vecs[: len(sentences)]
        chunk_vecs = all_vecs[len(sentences) :]
    except Exception as exc:
        logger.warning(f"Grounding embedding failed — skipping check: {exc}")
        # Treat as grounded to avoid discarding valid output
        return GroundingResult(is_grounded=True, grounding_score=1.0)

    flagged: List[str] = []
    grounded: List[str] = []

    for i, sentence in enumerate(sentences):
        sim = _max_cosine(sent_vecs[i], chunk_vecs)
        if sim >= threshold:
            grounded.append(sentence)
        else:
            flagged.append(sentence)
            logger.warning(f"Ungrounded sentence (sim={sim:.3f} < {threshold}): '{sentence[:80]}'")

    grounding_score = len(grounded) / len(sentences) if sentences else 1.0

    return GroundingResult(
        is_grounded=len(flagged) == 0,
        flagged_sentences=flagged,
        grounded_sentences=grounded,
        grounding_score=round(grounding_score, 3),
    )


def filter_ungrounded(
    generated_text: str,
    chunks: List[str],
    embedder: EmbeddingModel,
    threshold: Optional[float] = None,
) -> str:
    """
    Return *generated_text* with ungrounded sentences removed.

    If ALL sentences are filtered out (very aggressive threshold), the
    original text is returned unchanged to avoid an empty email.
    """
    result = check_grounding(generated_text, chunks, embedder, threshold)
    if result.grounded_sentences:
        return " ".join(result.grounded_sentences)
    # Fallback: return original to avoid empty output
    logger.warning("All sentences flagged as ungrounded; returning original text.")
    return generated_text
