"""
Semantic retrieval helpers for the RAG pipeline.
Wraps FAISSStore.search / search_for_lead with config-aware defaults.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from app.core.config import settings
from app.core.logging import get_logger

if TYPE_CHECKING:
    from app.rag.embeddings import EmbeddingModel
    from app.rag.vectorstore import FAISSStore

logger = get_logger(__name__)


def retrieve_chunks(
    query: str,
    store: FAISSStore,
    embedder: EmbeddingModel,
    k: Optional[int] = None,
) -> List[str]:
    """
    Return the top-k most relevant chunk texts for *query*.
    Falls back to settings.top_k_chunks when k is not provided.
    """
    k = k or settings.top_k_chunks
    query_vec = embedder.embed_one(query)
    results = store.search(query_vec, k=k)
    texts = [r.text for r in results if r.text.strip()]
    logger.debug(f"retrieve_chunks: got {len(texts)} for '{query[:60]}'")
    return texts


def retrieve_for_lead(
    lead_id: str,
    query: str,
    store: FAISSStore,
    embedder: EmbeddingModel,
    k: Optional[int] = None,
) -> List[str]:
    """
    Return the top-k chunk texts most relevant to *query* that
    belong specifically to *lead_id*.

    If the store has no lead-specific chunks, falls back to global search.
    """
    k = k or settings.top_k_chunks
    query_vec = embedder.embed_one(query)
    results = store.search_for_lead(query_vec, lead_id=lead_id, k=k)
    texts = [r.text for r in results if r.text.strip()]
    logger.debug(f"retrieve_for_lead: lead={lead_id[:8]} got {len(texts)} chunks")
    return texts
