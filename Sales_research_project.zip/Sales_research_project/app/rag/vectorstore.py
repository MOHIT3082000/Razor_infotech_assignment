"""
FAISS-backed vector store for the RAG pipeline.

Uses IndexFlatIP (inner product) which equals cosine similarity
for L2-normalised vectors produced by EmbeddingModel.

Metadata (text, source_url, lead_id) is stored in a plain dict
keyed by the integer insertion index.
"""
from __future__ import annotations

import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import faiss
import numpy as np

from app.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ChunkResult:
    text: str
    source_url: str
    lead_id: str
    score: float


class FAISSStore:
    """In-memory FAISS index with optional disk persistence."""

    def __init__(self, dim: int) -> None:
        self._dim = dim
        self._index = faiss.IndexFlatIP(dim)
        self._meta: Dict[int, Dict] = {}
        self._count = 0

    # ── write ──────────────────────────────────────────────────────────────────

    def add_chunks(
        self,
        chunks: List[str],
        embeddings: np.ndarray,
        lead_id: str,
        source_urls: Optional[List[str]] = None,
    ) -> None:
        """Add text chunks with their embeddings to the store."""
        if not chunks or embeddings.shape[0] == 0:
            return

        urls = source_urls or [""] * len(chunks)
        for i, chunk in enumerate(chunks):
            self._meta[self._count + i] = {
                "text": chunk,
                "source_url": urls[i] if i < len(urls) else "",
                "lead_id": lead_id,
            }

        self._index.add(embeddings.astype(np.float32))
        self._count += len(chunks)
        logger.debug(f"Added {len(chunks)} chunks for lead={lead_id}. Total={self._count}")

    # ── read ───────────────────────────────────────────────────────────────────

    def search(self, query_vector: np.ndarray, k: int = 5) -> List[ChunkResult]:
        """Return the top-k most similar chunks for *query_vector*."""
        if self._count == 0:
            return []

        k = min(k, self._count)
        q = query_vector.reshape(1, -1).astype(np.float32)
        scores, indices = self._index.search(q, k)

        results: List[ChunkResult] = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            meta = self._meta.get(int(idx), {})
            results.append(
                ChunkResult(
                    text=meta.get("text", ""),
                    source_url=meta.get("source_url", ""),
                    lead_id=meta.get("lead_id", ""),
                    score=float(score),
                )
            )
        return results

    def search_for_lead(
        self, query_vector: np.ndarray, lead_id: str, k: int = 5
    ) -> List[ChunkResult]:
        """Search globally then filter results to chunks belonging to *lead_id*."""
        # Retrieve more candidates to ensure enough survive the filter
        candidates = self.search(query_vector, k=min(k * 4, self._count))
        filtered = [r for r in candidates if r.lead_id == lead_id]
        # Fallback: if no lead-specific chunks, return global top-k
        return filtered[:k] if filtered else candidates[:k]

    # ── persistence ────────────────────────────────────────────────────────────

    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(path))
        meta_path = path.with_suffix(".pkl")
        with open(meta_path, "wb") as fh:
            pickle.dump({"meta": self._meta, "count": self._count}, fh)
        logger.info(f"FAISS index saved → {path} ({self._count} vectors)")

    @classmethod
    def load(cls, path: Path, dim: int) -> "FAISSStore":
        path = Path(path)
        store = cls(dim)
        store._index = faiss.read_index(str(path))
        meta_path = path.with_suffix(".pkl")
        with open(meta_path, "rb") as fh:
            data = pickle.load(fh)
        store._meta = data["meta"]
        store._count = data["count"]
        logger.info(f"FAISS index loaded ← {path} ({store._count} vectors)")
        return store
