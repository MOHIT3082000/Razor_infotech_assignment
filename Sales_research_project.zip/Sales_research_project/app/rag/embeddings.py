"""
Embedding model wrapper (SentenceTransformers).
A module-level singleton is used so the model is loaded once per process.
"""
from __future__ import annotations

from typing import List

import numpy as np
from sentence_transformers import SentenceTransformer

from app.core.logging import get_logger

logger = get_logger(__name__)

_DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
_instance: EmbeddingModel | None = None


class EmbeddingModel:
    """Thin wrapper around SentenceTransformer with normalized float32 output."""

    def __init__(self, model_name: str = _DEFAULT_MODEL) -> None:
        logger.info(f"Loading embedding model '{model_name}' ...")
        self._model = SentenceTransformer(model_name)
        self._dim: int = self._model.get_embedding_dimension()
        logger.info(f"Embedding model ready. Dimension = {self._dim}")

    @property
    def dim(self) -> int:
        return self._dim

    def embed(self, texts: List[str]) -> np.ndarray:
        """
        Encode a list of strings → float32 array of shape (N, dim).
        Vectors are L2-normalised so dot product == cosine similarity.
        """
        if not texts:
            return np.empty((0, self._dim), dtype=np.float32)
        vectors = self._model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return vectors.astype(np.float32)

    def embed_one(self, text: str) -> np.ndarray:
        """Convenience method — embed a single string → 1-D array of shape (dim,)."""
        return self.embed([text])[0]


def get_embedding_model() -> EmbeddingModel:
    """Return the process-wide singleton EmbeddingModel, loading it if needed."""
    global _instance
    if _instance is None:
        _instance = EmbeddingModel()
    return _instance
