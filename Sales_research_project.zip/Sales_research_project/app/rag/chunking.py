"""
Text chunking for the RAG pipeline.
Uses a fixed-size sliding window over characters with overlap.
"""
from __future__ import annotations

from typing import List

from app.core.logging import get_logger

logger = get_logger(__name__)


def chunk_text(
    text: str,
    chunk_size: int = 512,
    overlap: int = 50,
    min_length: int = 30,
) -> List[str]:
    """
    Split *text* into overlapping fixed-size chunks.

    Args:
        text:       Input text to chunk.
        chunk_size: Maximum characters per chunk.
        overlap:    Characters shared between consecutive chunks.
        min_length: Discard chunks shorter than this.

    Returns:
        List of non-empty chunk strings.
    """
    if not text or not text.strip():
        return []

    text = text.strip()
    chunks: List[str] = []
    start = 0
    step = max(1, chunk_size - overlap)

    while start < len(text):
        chunk = text[start : start + chunk_size].strip()
        if len(chunk) >= min_length:
            chunks.append(chunk)
        start += step

    logger.debug(f"chunked {len(text)} chars → {len(chunks)} chunks (size={chunk_size}, overlap={overlap})")
    return chunks


def chunk_lead_evidence(
    evidence_snippets: List[str],
    raw_text: str = "",
    chunk_size: int = 512,
    overlap: int = 50,
) -> List[str]:
    """
    Combine all evidence for a lead and chunk it.

    Concatenates evidence_snippets and raw_text (if provided),
    then delegates to chunk_text.
    """
    parts = [s for s in evidence_snippets if s.strip()]
    if raw_text.strip():
        parts.append(raw_text.strip())

    combined = " ".join(parts)
    return chunk_text(combined, chunk_size=chunk_size, overlap=overlap)
