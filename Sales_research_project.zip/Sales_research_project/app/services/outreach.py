"""
Outreach generation service.
Calls the local Ollama API with a grounded prompt that contains
ONLY the retrieved evidence chunks.  The model cannot invent facts
it was not given.
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, List, Tuple

import httpx

from app.core.config import settings
from app.core.logging import get_logger, log_api_failure

if TYPE_CHECKING:
    from app.schemas.lead import OutreachDraft, QualifiedLead

logger = get_logger(__name__)

_SYSTEM_INSTRUCTION = (
    "You are a professional sales development representative. "
    "Write concise, personalized outreach emails.\n\n"
    "CRITICAL RULE: Use ONLY the facts listed in RETRIEVED FACTS. "
    "Do NOT invent, assume, or add any information not present there. "
    "If facts are sparse, write a shorter email using only what is provided."
)


# ── Prompt builder ─────────────────────────────────────────────────────────────

def build_grounded_prompt(
    lead: "QualifiedLead",
    chunks: List[str],
    tone: str = "professional",
) -> str:
    """
    Build a prompt where the model is strictly constrained to the retrieved chunks.
    """
    tone_map = {
        "professional": "Use a professional, direct tone.",
        "friendly": "Use a warm, conversational tone.",
        "formal": "Use a formal, respectful tone.",
    }
    tone_instruction = tone_map.get(tone, tone_map["professional"])

    facts_block = (
        "\n".join(f"- {c.strip()}" for c in chunks if c.strip())
        if chunks
        else "- No specific facts retrieved. Keep the email generic and brief."
    )

    return f"""{_SYSTEM_INSTRUCTION}

RETRIEVED FACTS (use ONLY these):
{facts_block}

COMPANY: {lead.company_name}
KEYWORD/INDUSTRY: {lead.keyword}
TONE: {tone_instruction}

Write an outreach email:
1. Start the subject line with "Subject:"
2. Then write the email body (greeting → value proposition → CTA).
3. Keep the total email under 150 words.
"""


# ── Ollama client ──────────────────────────────────────────────────────────────

def call_ollama(prompt: str) -> str:
    """POST to the local Ollama /api/generate endpoint and return the response text."""
    try:
        with httpx.Client(timeout=120.0) as client:
            response = client.post(
                f"{settings.ollama_base_url}/api/generate",
                json={
                    "model": settings.ollama_model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.3,
                        "num_predict": 350,
                    },
                },
            )
            response.raise_for_status()
            return response.json().get("response", "").strip()
    except httpx.HTTPError as exc:
        log_api_failure(logger, "ollama:/api/generate", str(exc))
        raise RuntimeError(f"Ollama API error: {exc}") from exc


# ── Email parser ───────────────────────────────────────────────────────────────

def _parse_email_parts(raw: str) -> Tuple[str, str]:
    """Split model output into (subject, body)."""
    lines = raw.strip().splitlines()
    subject = ""
    body_lines: List[str] = []
    in_body = False

    for line in lines:
        if re.match(r"^subject\s*:", line, re.IGNORECASE):
            subject = re.sub(r"^subject\s*:\s*", "", line, flags=re.IGNORECASE).strip()
            in_body = True
        elif in_body:
            body_lines.append(line)

    body = "\n".join(body_lines).strip()

    if not subject:
        subject = f"Connecting with {lines[0][:60]}" if lines else "Introduction"
    if not body:
        body = raw  # return raw output if parsing fails

    return subject, body


# ── Main entry ─────────────────────────────────────────────────────────────────

def generate_outreach(
    lead: "QualifiedLead",
    chunks: List[str],
    tone: str = "professional",
) -> "OutreachDraft":
    """
    Generate a grounded outreach email for the given lead.
    Falls back to a static placeholder if Ollama is unreachable.
    """
    from app.schemas.lead import OutreachDraft

    prompt = build_grounded_prompt(lead, chunks, tone)

    try:
        raw_output = call_ollama(prompt)
        subject, body = _parse_email_parts(raw_output)
        return OutreachDraft(
            subject=subject,
            body=body,
            grounded=True,
            flagged_sentences=[],
            tone=tone,
        )
    except RuntimeError as exc:
        logger.error(f"Outreach generation failed for '{lead.company_name}': {exc}")
        return OutreachDraft(
            subject=f"Introduction — partnership opportunity",
            body=(
                "We were unable to generate a personalized email because the local "
                "LLM is unavailable. Please ensure Ollama is running and retry via "
                "POST /outreach."
            ),
            grounded=False,
            flagged_sentences=[],
            tone=tone,
        )
