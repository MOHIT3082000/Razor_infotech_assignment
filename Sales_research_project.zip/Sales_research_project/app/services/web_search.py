"""
Web search service using DuckDuckGo (no API key required).
Returns a normalised list of search hits for downstream scraping.
"""
from __future__ import annotations

import time
from typing import Dict, List

from duckduckgo_search import DDGS

from app.core.logging import get_logger, log_api_failure

logger = get_logger(__name__)


def search_leads(keyword: str, max_results: int = 10) -> List[Dict[str, str]]:
    """
    Search DuckDuckGo for company leads matching the keyword.

    Issues two complementary queries to improve coverage:
      1. "<keyword> company"
      2. "<keyword> business contact"

    Returns a deduplicated list of dicts: {title, url, snippet}.
    """
    queries = [
        f"{keyword} company",
        f"{keyword} business contact",
    ]
    per_query = max(max_results // len(queries) + 2, 5)

    results: List[Dict[str, str]] = []
    seen_urls: set[str] = set()

    for query in queries:
        if len(results) >= max_results:
            break
        try:
            with DDGS() as ddgs:
                hits = list(ddgs.text(query, max_results=per_query))

            for hit in hits:
                url = hit.get("href", "").strip()
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    results.append(
                        {
                            "title": hit.get("title", "").strip(),
                            "url": url,
                            "snippet": hit.get("body", "").strip(),
                        }
                    )

            # Respect DuckDuckGo rate limits
            time.sleep(1.0)

        except Exception as exc:
            log_api_failure(logger, f"duckduckgo:{query}", str(exc))
            logger.warning(f"Search query failed — '{query}': {exc}")

    trimmed = results[:max_results]
    logger.info(f"DuckDuckGo returned {len(trimmed)} results for '{keyword}'")
    return trimmed
