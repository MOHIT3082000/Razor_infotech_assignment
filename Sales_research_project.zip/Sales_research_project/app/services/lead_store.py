"""
Lead persistence service.
Saves and loads FinalLead objects as JSON files under data/leads/.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from app.core.config import settings
from app.core.logging import get_logger
from app.schemas.lead import FinalLead

logger = get_logger(__name__)


def _dir() -> Path:
    path = settings.leads_dir
    path.mkdir(parents=True, exist_ok=True)
    return path


def save_lead(lead: FinalLead) -> Path:
    """Serialise a FinalLead to data/leads/<id>.json."""
    path = _dir() / f"{lead.id}.json"
    path.write_text(lead.model_dump_json(indent=2), encoding="utf-8")
    logger.info(f"Lead saved: {lead.id} ({lead.company_name})")
    return path


def load_lead(lead_id: str) -> Optional[FinalLead]:
    """Load and deserialise a FinalLead by id. Returns None if not found."""
    path = _dir() / f"{lead_id}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return FinalLead(**data)
    except Exception as exc:
        logger.error(f"Failed to load lead '{lead_id}': {exc}")
        return None


def list_leads() -> List[FinalLead]:
    """Return all valid leads stored on disk."""
    leads: List[FinalLead] = []
    for path in sorted(_dir().glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            leads.append(FinalLead(**data))
        except Exception as exc:
            logger.warning(f"Skipping malformed lead file '{path.name}': {exc}")
    return leads


def lead_exists(lead_id: str) -> bool:
    """Return True if a lead JSON file exists for the given id."""
    return (_dir() / f"{lead_id}.json").exists()
