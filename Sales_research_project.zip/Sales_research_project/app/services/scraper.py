"""
Web scraper service.
Fetches a URL and extracts clean text + structured lead fields using
heuristics (BeautifulSoup + regex).  No LLM involved.
"""
from __future__ import annotations

from typing import Dict, List

import requests
from bs4 import BeautifulSoup

from app.core.logging import get_logger, log_api_failure
from app.utils.text_cleaning import (
    clean_text,
    extract_locations,
    extract_names,
)

logger = get_logger(__name__)

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}

# Tags that carry no useful content
_NOISE_TAGS = ["script", "style", "nav", "footer", "header", "aside", "noscript"]


def scrape_page(url: str, timeout: int = 10) -> str:
    """
    Fetch a page and return clean plain text.
    Returns an empty string on any failure.
    """
    try:
        resp = requests.get(url, headers=_HEADERS, timeout=timeout, allow_redirects=True)
        resp.raise_for_status()

        soup = BeautifulSoup(resp.text, "lxml")
        for tag in soup(_NOISE_TAGS):
            tag.decompose()

        raw = soup.get_text(separator=" ", strip=True)
        return clean_text(raw)

    except requests.RequestException as exc:
        log_api_failure(logger, url, str(exc))
        logger.warning(f"HTTP error scraping {url}: {exc}")
        return ""
    except Exception as exc:
        logger.warning(f"Parse error scraping {url}: {exc}")
        return ""


def extract_lead_fields(
    page_text: str, url: str, title: str, snippet: str
) -> Dict:
    """
    Extract structured lead fields from scrape + search result metadata.

    Returns a flat dict ready to populate a RawLead (minus id/keyword/created_at).
    """
    combined = f"{title} {snippet} {page_text[:3000]}"

    names: List[str] = extract_names(combined)
    locations: List[str] = extract_locations(combined)

    # Best-effort company name from page title
    company_name = _parse_company_name(title)

    # Use snippet as primary short description; fall back to first page sentence
    description = snippet[:500] if snippet else page_text[:500]

    # Evidence: snippet + first 1 000 chars of page body
    evidence: List[str] = []
    if snippet:
        evidence.append(snippet[:400])
    if page_text:
        evidence.append(page_text[:1000])

    return {
        "company_name": company_name,
        "website": url,
        "location": locations[0] if locations else None,
        "description": description,
        "decision_maker_hints": names[:5],
        "source_urls": [url],
        "evidence_snippets": evidence,
        "raw_text": page_text[:4000],
    }


# ── helpers ───────────────────────────────────────────────────────────────────

def _parse_company_name(title: str) -> str:
    """Extract company name from a page <title> string."""
    if not title:
        return "Unknown"
    # Strip common title suffixes like "Company – Home", "Company | About"
    for sep in (" - ", " | ", " — ", " – ", " :: "):
        if sep in title:
            return title.split(sep)[0].strip()
    return title.strip()[:120]
