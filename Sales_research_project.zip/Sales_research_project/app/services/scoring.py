"""
Deterministic lead scoring service.
No LLM involved — all scores are computed from measurable signals.

Rubric (max 100 pts):
  - Website present       : 20 pts
  - Description depth     : 25 pts  (word count of evidence)
  - Keyword relevance     : 25 pts  (cosine similarity vs. keyword)
  - Location present      : 10 pts
  - Decision-maker hints  : 20 pts  (job-title pattern matches)
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

import numpy as np

from app.core.logging import get_logger

if TYPE_CHECKING:
    from app.schemas.lead import LeadScore, RawLead
    from app.rag.embeddings import EmbeddingModel

logger = get_logger(__name__)

_TITLE_RE = re.compile(
    r"\b(CEO|CTO|CFO|COO|Director|Manager|Founder|Co-Founder|"
    r"President|VP|Head of|Partner|Principal)\b",
    re.IGNORECASE,
)


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def score_lead(lead: "RawLead", keyword: str, embedder: "EmbeddingModel") -> "LeadScore":
    """
    Compute and return a LeadScore for the given RawLead.
    All five factors are independent; failures in one do not affect others.
    """
    from app.schemas.lead import LeadScore

    # 1 ── Website (20 pts) ────────────────────────────────────────────────────
    website_score = 20.0 if lead.website else 0.0

    # 2 ── Description depth (25 pts) ─────────────────────────────────────────
    evidence_text = " ".join(lead.evidence_snippets)
    word_count = len(evidence_text.split())
    description_score = min(25.0, (word_count / 200.0) * 25.0)

    # 3 ── Keyword relevance (25 pts) ─────────────────────────────────────────
    keyword_relevance_score = 0.0
    if lead.description and keyword:
        try:
            vecs = embedder.embed([lead.description, keyword])
            sim = max(0.0, _cosine(vecs[0], vecs[1]))
            keyword_relevance_score = sim * 25.0
        except Exception as exc:
            logger.warning(f"Embedding failed during scoring for {lead.id}: {exc}")

    # 4 ── Location present (10 pts) ──────────────────────────────────────────
    location_score = 10.0 if lead.location else 0.0

    # 5 ── Decision-maker hints (20 pts) ──────────────────────────────────────
    dm_text = " ".join(lead.evidence_snippets) + " " + " ".join(lead.decision_maker_hints)
    title_hits = set(_TITLE_RE.findall(dm_text))
    if title_hits:
        dm_score = min(20.0, len(title_hits) * 5.0)
    elif lead.decision_maker_hints:
        dm_score = 10.0
    else:
        dm_score = 0.0

    total = website_score + description_score + keyword_relevance_score + location_score + dm_score

    reasoning = (
        f"Website {website_score}/20 | "
        f"Description depth {description_score:.1f}/25 (words={word_count}) | "
        f"Keyword relevance {keyword_relevance_score:.1f}/25 | "
        f"Location {location_score}/10 | "
        f"Decision-maker {dm_score}/20 (titles={list(title_hits)[:3]})"
    )

    return LeadScore(
        total=round(total, 2),
        website_score=round(website_score, 2),
        description_score=round(description_score, 2),
        keyword_relevance_score=round(keyword_relevance_score, 2),
        location_score=round(location_score, 2),
        decision_maker_score=round(dm_score, 2),
        reasoning=reasoning,
    )
