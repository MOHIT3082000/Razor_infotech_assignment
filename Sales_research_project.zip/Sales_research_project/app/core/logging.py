"""
Structured logging utilities for the lead generation system.
Provides latency tracking, agent event logging, API failure logging,
and lead quality metric logging.
"""
import json
import logging as std_logging
import time
from contextlib import contextmanager
from typing import Any


def get_logger(name: str) -> std_logging.Logger:
    """Return a configured logger for the given module name."""
    logger = std_logging.getLogger(name)
    if not logger.handlers:
        handler = std_logging.StreamHandler()
        formatter = std_logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.propagate = False
    logger.setLevel(std_logging.DEBUG)
    return logger


@contextmanager
def log_latency(logger: std_logging.Logger, operation: str):
    """Context manager that logs elapsed time for an operation."""
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = round(time.perf_counter() - start, 3)
        logger.info(
            json.dumps({"event": "latency", "operation": operation, "elapsed_s": elapsed})
        )


def log_agent_event(
    logger: std_logging.Logger,
    agent: str,
    action: str,
    data: dict[str, Any] | None = None,
) -> None:
    """Log a structured agent lifecycle event."""
    logger.info(
        json.dumps(
            {"event": "agent", "agent": agent, "action": action, "data": data or {}}
        )
    )


def log_api_failure(logger: std_logging.Logger, endpoint: str, error: str) -> None:
    """Log an external API failure with endpoint and error details."""
    logger.error(
        json.dumps({"event": "api_failure", "endpoint": endpoint, "error": error})
    )


def log_lead_quality(
    logger: std_logging.Logger,
    lead_id: str,
    score: float,
    flagged_sentences: list[str],
) -> None:
    """Log lead quality metrics including hallucination flags."""
    logger.info(
        json.dumps(
            {
                "event": "lead_quality",
                "lead_id": lead_id,
                "score": score,
                "hallucination_flags": len(flagged_sentences),
                "flagged": flagged_sentences,
            }
        )
    )
