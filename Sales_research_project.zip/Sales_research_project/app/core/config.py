from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Ollama
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2:3b"

    # Storage
    data_dir: str = "./data"

    # Logging
    log_level: str = "INFO"

    # RAG
    top_k_chunks: int = 5
    chunk_size: int = 512
    chunk_overlap: int = 50

    # Search
    max_search_results: int = 10

    # Grounding
    grounding_threshold: float = 0.30

    @property
    def leads_dir(self) -> Path:
        return Path(self.data_dir) / "leads"

    @property
    def indexes_dir(self) -> Path:
        return Path(self.data_dir) / "indexes"

    model_config = {"env_file": ".env", "extra": "ignore"}


settings = Settings()
