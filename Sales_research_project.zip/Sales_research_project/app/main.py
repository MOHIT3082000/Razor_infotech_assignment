"""
FastAPI application entry point.

Start with:
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.api.routes import router
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger("app.main")

app = FastAPI(
    title="AI Lead Generation & Research Agent",
    description=(
        "Multi-agent system for automated B2B lead research, qualification, "
        "and grounded outreach generation.\n\n"
        "Agents: Research → Qualification → Sales\n"
        "RAG: DuckDuckGo → scrape → chunk → FAISS → retrieve → Ollama"
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.include_router(router)


# ── Lifecycle ──────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup() -> None:
    """Ensure required data directories exist before accepting requests."""
    Path(settings.data_dir).mkdir(parents=True, exist_ok=True)
    settings.leads_dir.mkdir(parents=True, exist_ok=True)
    settings.indexes_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Data directory: {settings.data_dir}")
    logger.info(f"Ollama: {settings.ollama_base_url}  model: {settings.ollama_model}")


# ── Global exception handler ───────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error(f"Unhandled exception [{request.method} {request.url}]: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error": str(exc)},
    )
