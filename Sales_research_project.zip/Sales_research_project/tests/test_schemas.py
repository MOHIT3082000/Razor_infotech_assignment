"""
Tests for Pydantic schema models.
Validates that valid data is accepted and invalid data is rejected.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.schemas.lead import FinalLead, LeadScore, OutreachDraft, QualifiedLead, RawLead
from app.schemas.requests import OutreachRequest, RankRequest, ResearchRequest
from app.schemas.responses import HealthResponse, ResearchResponse


FIXTURE_DIR = Path(__file__).parent / "fixtures"


# ── RawLead ────────────────────────────────────────────────────────────────────

def test_raw_lead_minimal():
    lead = RawLead(company_name="Acme", keyword="fintech")
    assert lead.company_name == "Acme"
    assert lead.id  # auto-generated UUID


def test_raw_lead_full():
    lead = RawLead(
        company_name="Acme Fintech",
        website="https://acme.com",
        location="Bangalore",
        description="A payment company.",
        decision_maker_hints=["CEO John"],
        source_urls=["https://acme.com"],
        evidence_snippets=["Some evidence text."],
        keyword="fintech startups India",
    )
    assert lead.website == "https://acme.com"
    assert len(lead.evidence_snippets) == 1


def test_raw_lead_requires_keyword():
    with pytest.raises(ValidationError):
        RawLead(company_name="Acme")  # missing keyword


# ── LeadScore ──────────────────────────────────────────────────────────────────

def test_lead_score_defaults():
    score = LeadScore()
    assert score.total == 0.0
    assert score.reasoning == ""


def test_lead_score_values():
    score = LeadScore(
        total=85.0,
        website_score=20.0,
        description_score=22.5,
        keyword_relevance_score=22.5,
        location_score=10.0,
        decision_maker_score=10.0,
        reasoning="Test reasoning.",
    )
    assert score.total == 85.0


# ── ResearchRequest ────────────────────────────────────────────────────────────

def test_research_request_valid():
    req = ResearchRequest(keyword="fintech India", max_results=5)
    assert req.keyword == "fintech India"
    assert req.max_results == 5


def test_research_request_keyword_too_short():
    with pytest.raises(ValidationError):
        ResearchRequest(keyword="a")


def test_research_request_max_results_bounds():
    with pytest.raises(ValidationError):
        ResearchRequest(keyword="fintech", max_results=0)
    with pytest.raises(ValidationError):
        ResearchRequest(keyword="fintech", max_results=100)


# ── OutreachRequest ────────────────────────────────────────────────────────────

def test_outreach_request_valid():
    req = OutreachRequest(lead_id="abc-123", tone="friendly")
    assert req.tone == "friendly"


def test_outreach_request_invalid_tone():
    with pytest.raises(ValidationError):
        OutreachRequest(lead_id="abc-123", tone="aggressive")


# ── RankRequest ────────────────────────────────────────────────────────────────

def test_rank_request_valid():
    req = RankRequest(lead_ids=["id1", "id2"], sort_by="score")
    assert len(req.lead_ids) == 2


def test_rank_request_invalid_sort_by():
    with pytest.raises(ValidationError):
        RankRequest(lead_ids=["id1"], sort_by="revenue")


# ── FinalLead from fixture ─────────────────────────────────────────────────────

def test_final_lead_from_fixture():
    raw = json.loads((FIXTURE_DIR / "sample_lead.json").read_text())
    lead = FinalLead(**raw)
    assert lead.company_name == "Acme Fintech Solutions"
    assert lead.score.total == 85.0
    assert lead.outreach is not None
    assert lead.outreach.grounded is True


# ── HealthResponse ─────────────────────────────────────────────────────────────

def test_health_response():
    hr = HealthResponse(status="ok", ollama_connected=True, ollama_model="llama3.2:3b")
    assert hr.status == "ok"
    assert hr.version == "1.0.0"
