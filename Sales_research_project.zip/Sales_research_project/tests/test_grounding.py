"""
Tests for the hallucination grounding check.

These tests use a real EmbeddingModel so they test the actual cosine
similarity logic.  They are marked with the `slow` pytest marker so
they can be skipped during fast CI runs:

    pytest -m "not slow"        # skip embedding tests
    pytest -m slow              # run only embedding tests
"""
from __future__ import annotations

import pytest

from app.rag.grounding import GroundingResult, check_grounding, filter_ungrounded


@pytest.fixture(scope="module")
def embedder():
    """Load the embedding model once for all tests in this module."""
    from app.rag.embeddings import EmbeddingModel
    return EmbeddingModel()


# ── Edge-cases (no embedding needed) ──────────────────────────────────────────

def test_empty_generated_text(embedder):
    result = check_grounding("", ["Some chunk"], embedder)
    assert result.is_grounded is True
    assert result.grounding_score == 1.0


def test_empty_chunks(embedder):
    result = check_grounding("Some generated sentence.", [], embedder)
    assert result.is_grounded is False
    assert len(result.flagged_sentences) > 0


def test_short_sentences_below_min_length_skipped(embedder):
    # Sentences shorter than 10 chars are ignored by _split_sentences
    result = check_grounding("Yes. No.", ["Some context chunk."], embedder)
    # Both sentences too short → treated as grounded (no sentences to check)
    assert result.is_grounded is True


# ── Semantic grounding ─────────────────────────────────────────────────────────

@pytest.mark.slow
def test_grounded_sentence_passes(embedder):
    """A sentence that closely paraphrases a chunk should pass."""
    chunk = "Acme Fintech Solutions is headquartered in Bangalore, India."
    generated = "The company Acme Fintech is based in Bangalore."
    result = check_grounding(generated, [chunk], embedder, threshold=0.3)
    assert result.is_grounded is True
    assert len(result.flagged_sentences) == 0


@pytest.mark.slow
def test_invented_sentence_flagged(embedder):
    """A sentence with no relation to chunks should be flagged."""
    chunk = "Acme Fintech Solutions processes payments in India."
    generated = "The company was founded on Mars in the year 3000 by aliens."
    result = check_grounding(generated, [chunk], embedder, threshold=0.5)
    # The invented sentence should have low similarity to the chunk
    # We assert at least the flagged list is populated
    assert len(result.flagged_sentences) > 0 or result.grounding_score < 1.0


@pytest.mark.slow
def test_filter_ungrounded_returns_grounded_sentences(embedder):
    chunk = "PayFlow offers UPI-powered payment solutions in India."
    grounded_part = "PayFlow provides payment solutions in India."
    ungrounded_part = "Their next product will launch on the Moon in 2099."
    generated = f"{grounded_part} {ungrounded_part}"

    filtered = filter_ungrounded(generated, [chunk], embedder, threshold=0.4)
    # The filtered output should not be empty
    assert filtered.strip()


@pytest.mark.slow
def test_grounding_score_range(embedder):
    chunks = ["Bangalore-based company with 50 employees."]
    generated = "The company has 50 employees. It was founded in 1800 BC."
    result = check_grounding(generated, chunks, embedder, threshold=0.3)
    assert 0.0 <= result.grounding_score <= 1.0
