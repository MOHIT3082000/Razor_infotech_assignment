import pytest


def pytest_configure(config):
    config.addinivalue_line("markers", "slow: marks tests that load the embedding model (skip with -m 'not slow')")
