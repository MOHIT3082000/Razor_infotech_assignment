"""
Tests for the RAG chunking functions.
"""
from __future__ import annotations

import pytest

from app.rag.chunking import chunk_lead_evidence, chunk_text


# ── chunk_text ─────────────────────────────────────────────────────────────────

def test_empty_input_returns_empty():
    assert chunk_text("") == []
    assert chunk_text("   ") == []


def test_short_text_single_chunk():
    text = "Hello world this is a short sentence."
    chunks = chunk_text(text, chunk_size=512)
    assert len(chunks) == 1
    assert chunks[0] == text


def test_chunk_size_respected():
    text = "a" * 1000
    chunks = chunk_text(text, chunk_size=100, overlap=0)
    # Each chunk should be at most 100 chars
    for chunk in chunks:
        assert len(chunk) <= 100


def test_overlap_creates_shared_content():
    text = "abcdefghij" * 20   # 200 chars
    chunks = chunk_text(text, chunk_size=50, overlap=10, min_length=5)
    assert len(chunks) > 1
    # Consecutive chunks share the last `overlap` chars of the previous chunk
    assert chunks[0][-10:] == chunks[1][:10]


def test_min_length_filter():
    text = "Hi. " + "Long enough text here to survive the filter. " * 5
    chunks = chunk_text(text, chunk_size=512, overlap=0, min_length=30)
    for chunk in chunks:
        assert len(chunk) >= 30


def test_none_like_values():
    assert chunk_text(None) == []  # type: ignore[arg-type]


# ── chunk_lead_evidence ───────────────────────────────────────────────────────

def test_chunk_lead_evidence_combines_snippets():
    snippets = ["First snippet.", "Second snippet."]
    chunks = chunk_lead_evidence(snippets, chunk_size=512)
    assert len(chunks) >= 1
    combined = " ".join(chunks)
    assert "First" in combined
    assert "Second" in combined


def test_chunk_lead_evidence_includes_raw_text():
    snippets = ["Snippet."]
    raw = "Raw page text that provides additional context."
    chunks = chunk_lead_evidence(snippets, raw_text=raw, chunk_size=512)
    combined = " ".join(chunks)
    assert "Raw page text" in combined


def test_chunk_lead_evidence_empty():
    chunks = chunk_lead_evidence([], raw_text="", chunk_size=512)
    assert chunks == []
