"""
Tests for the deterministic lead scoring rubric.
Each factor is tested in isolation.
"""
from __future__ import annotations

from unittest.mock import MagicMock

import numpy as np
import pytest

from app.schemas.lead import RawLead
from app.services.scoring import score_lead


def _make_lead(**kwargs) -> RawLead:
    defaults = dict(
        company_name="Test Co",
        keyword="fintech",
        evidence_snippets=[],
        decision_maker_hints=[],
    )
    defaults.update(kwargs)
    return RawLead(**defaults)


def _mock_embedder(sim: float = 0.8) -> MagicMock:
    """Return a mock EmbeddingModel whose embed() returns vectors with known cosine sim."""
    embedder = MagicMock()
    # Two identical vectors → cosine sim = 1.0; controlled via sim parameter
    vec_a = np.array([sim, (1 - sim**2) ** 0.5], dtype=np.float32)
    vec_b = np.array([1.0, 0.0], dtype=np.float32)
    embedder.embed.return_value = np.array([vec_a, vec_b], dtype=np.float32)
    return embedder


# ── Website score ──────────────────────────────────────────────────────────────

def test_website_score_present():
    lead = _make_lead(website="https://testco.com")
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.website_score == 20.0


def test_website_score_absent():
    lead = _make_lead(website=None)
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.website_score == 0.0


# ── Description depth score ───────────────────────────────────────────────────

def test_description_depth_zero_words():
    lead = _make_lead(evidence_snippets=[])
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.description_score == 0.0


def test_description_depth_capped():
    # 200 words should give exactly 25 pts
    text = " ".join(["word"] * 200)
    lead = _make_lead(evidence_snippets=[text])
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.description_score == 25.0


def test_description_depth_partial():
    # 100 words → 12.5 pts
    text = " ".join(["word"] * 100)
    lead = _make_lead(evidence_snippets=[text])
    score = score_lead(lead, "fintech", _mock_embedder())
    assert abs(score.description_score - 12.5) < 0.1


# ── Location score ────────────────────────────────────────────────────────────

def test_location_score_present():
    lead = _make_lead(location="Bangalore, India")
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.location_score == 10.0


def test_location_score_absent():
    lead = _make_lead(location=None)
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.location_score == 0.0


# ── Decision-maker score ───────────────────────────────────────────────────────

def test_dm_score_with_titles_in_evidence():
    lead = _make_lead(
        evidence_snippets=["CEO John Doe founded the company. CTO Jane Smith leads engineering."]
    )
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.decision_maker_score > 0.0


def test_dm_score_with_hints_only():
    lead = _make_lead(decision_maker_hints=["John Doe"])
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.decision_maker_score == 10.0


def test_dm_score_none():
    lead = _make_lead()
    score = score_lead(lead, "fintech", _mock_embedder())
    assert score.decision_maker_score == 0.0


# ── Total ─────────────────────────────────────────────────────────────────────

def test_total_is_sum_of_parts():
    lead = _make_lead(
        website="https://testco.com",
        location="India",
        evidence_snippets=["CEO John Smith leads. " + " ".join(["detail"] * 100)],
        decision_maker_hints=["CEO"],
        description="fintech payment startup",
    )
    score = score_lead(lead, "fintech", _mock_embedder(sim=0.9))
    expected = (
        score.website_score
        + score.description_score
        + score.keyword_relevance_score
        + score.location_score
        + score.decision_maker_score
    )
    assert abs(score.total - round(expected, 2)) < 0.01


def test_total_never_exceeds_100():
    lead = _make_lead(
        website="https://testco.com",
        location="India",
        evidence_snippets=[" ".join(["word"] * 500)],
        decision_maker_hints=["CEO", "CTO", "CFO", "COO"],
        description="fintech",
    )
    score = score_lead(lead, "fintech", _mock_embedder(sim=1.0))
    assert score.total <= 100.0
